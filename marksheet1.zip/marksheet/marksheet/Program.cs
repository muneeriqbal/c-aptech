﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marksheet
{
    class Program
    {
        static void Main(string[] args)
        {
            int eng, urdu, state, comp, phy, math, total, per;
            string grade = "-x-";

            Console.WriteLine("Enter Your Obtained Marks:\n");
            Console.WriteLine("S.No\tSubject \tSubject Marks \tObtained Marks");
            Console.Write("\n1\tEnglish \t 100 \t\t ");
            eng = Int32.Parse(Console.ReadLine());
            Console.Write("\n2\tUrdu \t\t 100 \t\t ");
            urdu = Int32.Parse(Console.ReadLine());
            Console.Write("\n3\tStatistic \t 100 \t\t ");
            state = Int32.Parse(Console.ReadLine());
            Console.Write("\n4\tComputer \t 100 \t\t ");
            comp = Int32.Parse(Console.ReadLine());
            Console.Write("\n5\tPhysics \t 100 \t\t ");
            phy = Int32.Parse(Console.ReadLine());
            Console.Write("\n6\tMathametics \t 100 \t\t ");
            math = Int32.Parse(Console.ReadLine());
            Console.WriteLine("  \t");

            if ((eng <= 100) & (urdu <= 100) & (state <= 100) & (comp <= 100) & (phy <= 100) & (math <= 100))
            {
                total = eng + urdu + state + comp + phy + math;


                per = total * 100 / 600;



                if (per >= 80 & per <= 100)
                {
                    Console.WriteLine("\nTotal Subjects\t\t6\n\nTotal Marks \t\t600 \n\nTotal Obtained Marks\t" + total);
                    Console.WriteLine("\npercentage \t\t" + per + "%\n");
                    grade = "A+";
                }
                else if (per >= 70 & per <= 79)
                {
                    Console.WriteLine("\nTotal Subjects\t\t6\n\nTotal Marks \t\t600 \n\nTotal Obtained Marks\t" + total);
                    Console.WriteLine("\npercentage \t\t" + per + "%\n");
                    grade = "A";
                }
                else if (per >= 60 & per <= 69)
                {
                    Console.WriteLine("\nTotal Subjects\t\t6\n\nTotal Marks \t\t600 \n\nTotal Obtained Marks\t" + total);
                    Console.WriteLine("\npercentage \t\t" + per + "%\n");
                    grade = "B";
                }
                else if (per >= 50 & per <= 59)
                {
                    Console.WriteLine("\nTotal Subjects\t\t6\n\nTotal Marks \t\t600 \n\nTotal Obtained Marks\t" + total);
                    Console.WriteLine("\npercentage \t\t" + per + "%\n");
                    grade = "C";
                }
                else if (per < 50)
                {
                    Console.WriteLine("\nTotal Subjects\t\t6\n\nTotal Marks \t\t600 \n\nTotal Obtained Marks\t" + total);
                    Console.WriteLine("\npercentage \t\t" + per + "%\n");
                    grade = "Fail";
                }

                Console.WriteLine("Grade \t\t\t" + grade);
            }
            else
            {
                Console.WriteLine("\nTotal Subjects\t\t6\n\nTotal Marks \t\t600 \n\nTotal Obtained Marks\t-x-");
                Console.WriteLine("\npercentage \t\t-x- \n\nGrade \t\t\t" + grade + "\n");
                Console.WriteLine("please enter marks out of Subject Marks...!\n");
            }

            Console.ReadLine();

        }
    }
}
