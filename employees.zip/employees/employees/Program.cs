﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employees
{

    public class Employee 
    {
       
        private int age, salary;
        
        internal string F_Name = "muneer", L_name = "iqbal";
    
        public virtual void Emp_full_Name() 
        {
            Console.WriteLine(F_Name + " " + L_name + "\t\t\t\t(virtual medthod)\n");
        }
    
        // medthod with zero perameters
        public void Emp_Detail() 
        {
            Console.WriteLine(F_Name + " " + L_name + " " + age + " " + salary + "\t\t\t(medthod with zero perameters)\n");

        }

        // medthod with two perameters
        public void Emp_Detail(int Age, int Salary)
        {
            age = Age;
            salary = Salary;

            Console.WriteLine(F_Name + " " + L_name + " " + age + " " + salary + "\t\t\t(medthod with two perameters)\n");
        }

        //medthod with two perameters but change data type
        public void Emp_Detail(string f_name, int Age)
        {
            F_Name = f_name;
            age = Age;

            Console.WriteLine(F_Name + " " + L_name + " " + age + " " + salary + "\t\t\t(medthod with two perameters but change data type)\n");
        }

        //medthod with four perameters
        public void Emp_Detail(string f_name, string l_name,int Age, int Salary)
        {
            F_Name = f_name;
            L_name = l_name;
            age = Age;
            salary = Salary;

            Console.WriteLine(F_Name + " " + L_name + " " + age + " " + salary + "\t\t\t(medthod with four perameters)\n");
        }
    }

    public class Part_Time : Employee
    {
      
        public override void Emp_full_Name()
        {
            Console.WriteLine(F_Name + " " + L_name + "\t (Part - time)\t\t(override medthod)\n");
        }
       
    }

    public class Full_Time : Employee
    {
        public override void Emp_full_Name()
        {
            Console.WriteLine(F_Name + " " + L_name + "\t (Full - time)\t\t(override medthod)\n");
        }
    }

    public class temporary : Employee
    {
        public override void Emp_full_Name()
        {
            Console.WriteLine(F_Name + " " + L_name + "\t (Temporary)\t\t(override medthod)\n");
        }
    }


    class Program 
    {
        static void Main(string[] args)
        {
            Employee e = new Employee();
            Console.WriteLine(e.F_Name+" "+e.L_name+"\t\t\t\t(for acess modifier)\n");
            
                    
            Employee [] array_var = new Employee[4];
            array_var[0] = new Employee();
            array_var[1] = new Part_Time();
            array_var[2] = new Full_Time();
            array_var[3] = new temporary();

            foreach (Employee obj in array_var) 
            {
                obj.Emp_full_Name();
            }

            temporary emp = new temporary();

            emp.Emp_Detail();

            emp.Emp_Detail(40, 10000);

            emp.Emp_Detail("hussain", 50);

            emp.Emp_Detail("iqbal", "hussain",30,10000);
           
                Console.ReadLine();
        }
    }
}
