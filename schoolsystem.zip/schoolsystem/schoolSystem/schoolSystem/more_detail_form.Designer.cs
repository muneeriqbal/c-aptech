﻿namespace schoolSystem
{
    partial class more_detail_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.update = new System.Windows.Forms.Button();
            this.moreDetail = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.update);
            this.panel1.Controls.Add(this.moreDetail);
            this.panel1.Controls.Add(this.delete);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(886, 69);
            this.panel1.TabIndex = 34;
            // 
            // label25
            // 
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label25.Font = new System.Drawing.Font("Lucida Fax", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Location = new System.Drawing.Point(30, 12);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(329, 46);
            this.label25.TabIndex = 32;
            this.label25.Text = "ALL STUDENT\'S PROFILE";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.update.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.ForeColor = System.Drawing.Color.Black;
            this.update.Image = global::schoolSystem.Properties.Resources.icon;
            this.update.Location = new System.Drawing.Point(475, 3);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(115, 57);
            this.update.TabIndex = 13;
            this.update.Text = "Updates";
            this.update.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.update.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.update.UseVisualStyleBackColor = false;
            // 
            // moreDetail
            // 
            this.moreDetail.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.moreDetail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.moreDetail.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moreDetail.ForeColor = System.Drawing.Color.Black;
            this.moreDetail.Image = global::schoolSystem.Properties.Resources.more_options__1_;
            this.moreDetail.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.moreDetail.Location = new System.Drawing.Point(717, 3);
            this.moreDetail.Name = "moreDetail";
            this.moreDetail.Size = new System.Drawing.Size(115, 57);
            this.moreDetail.TabIndex = 12;
            this.moreDetail.Text = "More Detail";
            this.moreDetail.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.moreDetail.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.moreDetail.UseVisualStyleBackColor = false;
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.delete.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Italic);
            this.delete.ForeColor = System.Drawing.Color.Black;
            this.delete.Image = global::schoolSystem.Properties.Resources.computing_cloud__1_;
            this.delete.Location = new System.Drawing.Point(596, 3);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(115, 57);
            this.delete.TabIndex = 11;
            this.delete.Text = "Delete";
            this.delete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.delete.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.delete.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(12, 113);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(862, 399);
            this.panel2.TabIndex = 33;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.SeaGreen;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.Info;
            this.button5.Image = global::schoolSystem.Properties.Resources.go_back_arrow__2_;
            this.button5.Location = new System.Drawing.Point(744, 77);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(129, 30);
            this.button5.TabIndex = 38;
            this.button5.Text = "Go Back";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Employee Name :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(15, 35);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(276, 24);
            this.textBox1.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(219, 23);
            this.label2.TabIndex = 13;
            this.label2.Text = "Father/Husband Name :";
            // 
            // more_detail_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::schoolSystem.Properties.Resources.colored_pencils_3141508_960_720;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(886, 524);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "more_detail_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "more_detail_form";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button moreDetail;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
    }
}