﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace schoolSystem
{
    public partial class Student_Fee : Form
    {
        public Student_Fee()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_registration_Click(object sender, EventArgs e)
        {
            home h = new home();
           
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void fee_salary_Load(object sender, EventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            ////////////////////////////////
        }
    }
}
