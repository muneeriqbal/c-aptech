﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marksheet
{
    class Program
    {
        static void Main(string[] args)
        {
            int eng, urdu, state, comp, phy, math, total, per;
            string grade;


            Console.WriteLine("Enter Your Obtained Marks:");
            Console.WriteLine("Subject \tSubject Marks \tObtained Marks");
            Console.Write("\nEnglish \t 100 \t\t");
            eng = Int32.Parse(Console.ReadLine());
            Console.Write("\nUrdu \t\t 100 \t\t");
            urdu = Int32.Parse(Console.ReadLine());
            Console.Write("\nStatistic \t 100 \t\t");
            state = Int32.Parse(Console.ReadLine());
            Console.Write("\nComputer \t 100 \t\t");
            comp = Int32.Parse(Console.ReadLine());
            Console.Write("\nPhysics \t 100 \t\t");
            phy = Int32.Parse(Console.ReadLine());
            Console.Write("\nMathametics \t 100 \t\t");
            math = Int32.Parse(Console.ReadLine());
            Console.WriteLine("\nTotal Subjects \tTotal Marks \tTotal Obtained Marks");
            
            total = eng+urdu+state+comp+phy+math;
            Console.WriteLine("6 \t\t600 \t\t"+ total);

            per = total * 100 / 600;
            Console.WriteLine("\npercentage \t" +per+ "%\n");
            

            if(per >= 80 & per <= 100){
                grade = "A+";
                Console.WriteLine("Grade \t" + grade);
            }
            else if(per >=70 & per <= 79)
            {
                grade = "A";
                Console.WriteLine("Grade \t" + grade);
            }
            else if (per >= 60 & per <= 69)
            {
                grade = "B";
                Console.WriteLine("Grade \t" + grade);
            }
            else if (per >= 50 & per <= 59)
            {
                grade = "C";
                Console.WriteLine("Grade \t" + grade);
            }
            else if (per < 50)
            {
                grade = "Fail";
                Console.WriteLine("Grade \t" + grade);
            }
            else 
            {
                Console.WriteLine("please enter marks out of 100");
            }


            
            Console.ReadLine();


        }
    }
}
