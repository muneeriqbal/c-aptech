﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace schoolSystem
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel_teacher_reg.Visible = false;
            panel_teacher_btn.Visible = false;
            button2.Visible = false;
            panel_student_reg.Visible = true;
            panel_student_btn.Visible = true;
            teacher_btn.Visible = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel_teacher_reg.Visible = true;
            panel_teacher_btn.Visible = true;
            button2.Visible = true;
            panel_student_reg.Visible = false;
            panel_student_btn.Visible = false;
            teacher_btn.Visible = false;
        }
    }
}
