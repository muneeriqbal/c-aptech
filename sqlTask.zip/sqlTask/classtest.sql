create database test;
use test;

create table Worker(workerId int not null identity(001,1), 
FIRST_NAME varchar(max), LAST_NAME varchar(max), SALARY int , joiningDate varchar(max),
DEPARTMENT varchar(max) );

drop table Worker;

create table bonus(worker_Ref_id int not null , bonusDate varchar(max),
bonusAmount int   );

create table title(
worker_Ref_Id int not null
,workerTitle varchar(20), affectedFrom varchar(max)
);

select * from Worker;
insert into Worker values('Monika', 'Arora', 100000, '2014-02-20 09:00:00' , 'HR');

insert into Worker values('Niharika', 'Verma',80000 , '2014-06-11 90:00:00', 'Admin');

insert into Worker values('Vishal', 'Singhal', 300000, '2014-02-20 90:00:00', 'HR');

insert into Worker values('Amitabh', 'Singh', 500000, '2014-02-20 90:00:00', 'Admin');

insert into Worker values('Vivek', 'Bhati', 500000, '2014-06-11 90:00:00', 'Admin');

insert into Worker values('Vipul', 'Diwan', 200000, '2014-06-11 90:00:00' , 'Account');

insert into Worker values('Satish', 'Kumar', 75000, '2014-01-20 90:00:00', 'Account');

insert into Worker values('Geetika', 'Chauhan', 90000, '2014-04-11 90:00:00', 'Admin');

select * from bonus;
insert into bonus values(1,'2016-02-20 00:00:00',5000);

insert into bonus values(2,'2016-06-11 00:00:00',3000);

insert into bonus values(3,'2016-02-20 00:00:00',4000);

insert into bonus values(1,'2016-02-20 00:00:00',4500);

insert into bonus values(2,'2016-06-11 00:00:00',3500);

select * from title;
insert into title (WORKER_REF_ID, WORKER_TITLE, AFFECTED_FROM) values 

(1,'Manager','2016-02-20 00:00:00');

(2,'Executive','2016-06-11 00:00:00');

(8,'Executive','2016-06-11 00:00:00');

(5,'Manager','2016-06-11 00:00:00');

(4,'Asst. Manager','2016-06-11 00:00:00');

(7,'Executive','2016-06-11 00:00:00');

(6,'Lead','2016-06-11 00:00:00');

(3,'Lead','2016-06-11 00:00:00');

--Q1.
select * from Worker;

--Q2.
select * from Worker;
select UPPER(fname) from Worker

--Q3.
select * from Worker;
select distinct(dep) from Worker

--Q4.
Select distinct length(DEPARTMENT) from Worker;

--Q5.
Select REPLACE(FIRST_NAME,'a','A') from Worker;

--Q6.
Select CONCAT(FIRST_NAME, ' ', LAST_NAME) AS 'COMPLETE_NAME' from Worker;

--Q7.
Select * from Worker order by FIRST_NAME asc;

--Q8.
Select * from Worker order by FIRST_NAME asc,DEPARTMENT desc;

--Q9.
Select * from Worker where FIRST_NAME in ('Vipul','Satish');

--Q10.
Select * from Worker where FIRST_NAME not in ('Vipul','Satish');

--Q11.
Select * from Worker where DEPARTMENT like 'Admin%';

--Q12.
Select * from Worker where FIRST_NAME like '%a%';

--Q13.
Select * from Worker where FIRST_NAME like '%a';

--Q14.
Select * from Worker where SALARY between 100000 and 500000;

--Q15.
SELECT COUNT(*) FROM worker WHERE DEPARTMENT = 'Admin';