﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

abstract class emp 
{
    public int per_hour = 100, salary = 0, total_hour = 0, fix_time = 8;
    public string name;

    public abstract void display();
    public void salary_Count(int bonus ,int overtime) 
    {
        salary = per_hour * fix_time;
        total_hour = overtime + fix_time;
        if (total_hour > fix_time) 
        {
            overtime = total_hour - fix_time;
            salary = salary + (overtime * per_hour);
        }
        Console.WriteLine("bonus is {0},and over time is {1}", bonus, overtime);
        bonus = salary + bonus;
        
    }
}
class worker : emp 
{
    public override void display()
    {
        Console.WriteLine("name = {0}, fix time = {1}, per hour ={2}",name,fix_time,per_hour);
        Console.WriteLine("{0} total salary is: {1}", name, salary);
    }
}


namespace abstract_class_and_method
{
    class Program
    {
        static void Main(string[] args)
        {
            worker obj = new worker();
            obj.name = "worker";
            obj.salary_Count(2,7);
            obj.display();
            Console.ReadKey();
        }
    }
}
